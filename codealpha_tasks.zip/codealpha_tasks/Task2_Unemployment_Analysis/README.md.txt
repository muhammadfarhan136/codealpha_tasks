# 📊 Task 2: Unemployment Analysis with Python

> **CodeAlpha Data Science Internship - Task 2**

Analyzing unemployment rate data in India with focus on COVID-19 impact, 
seasonal trends, and state-wise patterns.

## 🎯 Objectives
- Analyze unemployment rate trends
- Investigate COVID-19 impact on employment
- Identify state-wise patterns
- Discover seasonal trends

## 📊 Key Insights
- **COVID-19 Impact:** Unemployment rate increased significantly during lockdown
- **Most Affected States:** [Add based on your analysis]
- **Urban vs Rural:** Different patterns observed
- **Seasonal Trends:** Clear monthly variations

## 🛠️ Tech Stack
- Python
- Pandas, NumPy
- Matplotlib, Seaborn, Plotly
- Jupyter Notebook

## 📁 Structure
\`\`\`
Task2_Unemployment_Analysis/
├── data/
├── notebooks/
├── visualizations/
└── main.py
\`\`\`

## 🚀 How to Run
\`\`\`bash
pip install -r requirements.txt
jupyter notebook notebooks/unemployment_analysis.ipynb
\`\`\`

## 📸 Visualizations
![Trend](visualizations/unemployment_trend.png)
![COVID Impact](visualizations/covid_impact.png)