"""
Task 2: Unemployment Analysis with Python
CodeAlpha Data Science Internship
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Style settings
sns.set_style('whitegrid')
plt.rcParams['figure.figsize'] = (12, 6)


def load_data(path='data/unemployment.csv'):
    """Load the unemployment dataset"""
    print("\n📥 Loading dataset...")
    df = pd.read_csv(path)
    print(f"   ✅ Dataset loaded! Shape: {df.shape}")
    return df


def clean_data(df):
    """Clean and preprocess the data"""
    print("\n🔧 Cleaning data...")
    
    # Remove extra spaces from column names
    df.columns = df.columns.str.strip()
    
    # Convert date column to datetime
    df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)
    
    # Extract month and year
    df['Month'] = df['Date'].dt.month
    df['Year'] = df['Date'].dt.year
    df['Month_Name'] = df['Date'].dt.month_name()
    
    # Check missing values
    missing = df.isnull().sum().sum()
    print(f"   Missing values: {missing}")
    
    if missing > 0:
        df = df.dropna()
        print("   ✅ Missing values removed")
    
    print(f"   ✅ Data cleaned! Final shape: {df.shape}")
    return df


def basic_statistics(df):
    """Display basic statistics"""
    print("\n" + "=" * 60)
    print("📈 BASIC STATISTICS")
    print("=" * 60)
    
    unemployment_col = 'Estimated Unemployment Rate (%)'
    
    print(f"\n📊 Average Unemployment Rate: {df[unemployment_col].mean():.2f}%")
    print(f"📊 Maximum Unemployment Rate: {df[unemployment_col].max():.2f}%")
    print(f"📊 Minimum Unemployment Rate: {df[unemployment_col].min():.2f}%")
    print(f"📊 Standard Deviation: {df[unemployment_col].std():.2f}%")


def plot_unemployment_trend(df):
    """Plot overall unemployment trend over time"""
    print("\n📊 Generating: Overall Unemployment Trend...")
    
    plt.figure(figsize=(14, 6))
    trend = df.groupby('Date')['Estimated Unemployment Rate (%)'].mean()
    plt.plot(trend.index, trend.values, color='red', linewidth=2)
    plt.title('Average Unemployment Rate Over Time in India', fontsize=14, fontweight='bold')
    plt.xlabel('Date', fontsize=12)
    plt.ylabel('Unemployment Rate (%)', fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('visualizations/unemployment_trend.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/unemployment_trend.png")
    plt.show()


def plot_state_wise(df):
    """Plot state-wise unemployment rates"""
    print("\n📊 Generating: State-wise Unemployment...")
    
    state_data = df.groupby('Region')['Estimated Unemployment Rate (%)'].mean().sort_values(ascending=False)
    
    plt.figure(figsize=(14, 10))
    sns.barplot(x=state_data.values, y=state_data.index, palette='Reds_r')
    plt.title('Average Unemployment Rate by State', fontsize=14, fontweight='bold')
    plt.xlabel('Unemployment Rate (%)', fontsize=12)
    plt.ylabel('State', fontsize=12)
    plt.tight_layout()
    plt.savefig('visualizations/state_wise.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/state_wise.png")
    plt.show()
    
    return state_data


def plot_covid_impact(df):
    """Analyze COVID-19 impact on unemployment"""
    print("\n📊 Generating: COVID-19 Impact Analysis...")
    
    # Separate before and during COVID
    df['Period'] = df['Date'].apply(
        lambda x: 'Before COVID' if x < pd.Timestamp('2020-04-01') else 'During COVID'
    )
    
    covid_impact = df.groupby('Period')['Estimated Unemployment Rate (%)'].mean()
    
    plt.figure(figsize=(10, 6))
    colors = ['#2ecc71', '#e74c3c']
    bars = plt.bar(covid_impact.index, covid_impact.values, color=colors, edgecolor='black')
    plt.title('Unemployment Rate: Before vs During COVID-19', fontsize=14, fontweight='bold')
    plt.ylabel('Average Unemployment Rate (%)', fontsize=12)
    
    # Add values on top of bars
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}%', ha='center', va='bottom', fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('visualizations/covid_impact.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/covid_impact.png")
    plt.show()
    
    return covid_impact


def plot_urban_rural(df):
    """Compare urban vs rural unemployment"""
    print("\n📊 Generating: Urban vs Rural Comparison...")
    
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Area', y='Estimated Unemployment Rate (%)', data=df, palette='Set2')
    plt.title('Unemployment Rate: Urban vs Rural', fontsize=14, fontweight='bold')
    plt.xlabel('Area', fontsize=12)
    plt.ylabel('Unemployment Rate (%)', fontsize=12)
    plt.tight_layout()
    plt.savefig('visualizations/urban_rural.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/urban_rural.png")
    plt.show()


def plot_seasonal_trends(df):
    """Analyze monthly/seasonal patterns"""
    print("\n📊 Generating: Seasonal Trends...")
    
    monthly_avg = df.groupby('Month')['Estimated Unemployment Rate (%)'].mean()
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
              'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    plt.figure(figsize=(12, 6))
    plt.plot(months[:len(monthly_avg)], monthly_avg.values, 
             marker='o', linewidth=2, markersize=10, color='purple')
    plt.title('Seasonal Pattern - Monthly Average Unemployment', fontsize=14, fontweight='bold')
    plt.xlabel('Month', fontsize=12)
    plt.ylabel('Unemployment Rate (%)', fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('visualizations/seasonal_trends.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/seasonal_trends.png")
    plt.show()


def plot_heatmap(df):
    """Generate correlation heatmap"""
    print("\n📊 Generating: Correlation Heatmap...")
    
    numeric_cols = ['Estimated Unemployment Rate (%)', 
                    'Estimated Employed', 
                    'Estimated Labour Participation Rate (%)']
    
    # Filter only existing columns
    available_cols = [col for col in numeric_cols if col in df.columns]
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(df[available_cols].corr(), annot=True, cmap='coolwarm', 
                fmt='.2f', linewidths=1)
    plt.title('Correlation Heatmap', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('visualizations/heatmap.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/heatmap.png")
    plt.show()


def print_insights(df, state_data, covid_impact):
    """Print key insights from the analysis"""
    print("\n" + "=" * 60)
    print("💡 KEY INSIGHTS")
    print("=" * 60)
    
    unemployment_col = 'Estimated Unemployment Rate (%)'
    
    print(f"\n1️⃣ Overall Statistics:")
    print(f"   • Average unemployment rate: {df[unemployment_col].mean():.2f}%")
    print(f"   • Highest recorded rate: {df[unemployment_col].max():.2f}%")
    
    print(f"\n2️⃣ COVID-19 Impact:")
    print(f"   • Before COVID: {covid_impact['Before COVID']:.2f}%")
    print(f"   • During COVID: {covid_impact['During COVID']:.2f}%")
    increase = covid_impact['During COVID'] - covid_impact['Before COVID']
    print(f"   • Increase: {increase:.2f}% ({(increase/covid_impact['Before COVID']*100):.1f}% rise)")
    
    print(f"\n3️⃣ State Analysis:")
    print(f"   • Most affected state: {state_data.index[0]} ({state_data.values[0]:.2f}%)")
    print(f"   • Least affected state: {state_data.index[-1]} ({state_data.values[-1]:.2f}%)")
    
    print(f"\n4️⃣ Area Analysis:")
    if 'Area' in df.columns:
        area_avg = df.groupby('Area')[unemployment_col].mean()
        for area, rate in area_avg.items():
            print(f"   • {area}: {rate:.2f}%")
    
    print("\n" + "=" * 60)
    print("📋 RECOMMENDATIONS FOR POLICY MAKERS")
    print("=" * 60)
    print("""
    ✔️ Focus on states with highest unemployment for targeted job programs
    ✔️ Prepare contingency plans for future pandemic-like situations
    ✔️ Invest in skill development programs in most affected regions
    ✔️ Address seasonal employment gaps through year-round opportunities
    ✔️ Develop separate strategies for urban and rural unemployment
    """)


def main():
    """Main execution function"""
    print("=" * 60)
    print("📊 UNEMPLOYMENT ANALYSIS WITH PYTHON")
    print("   CodeAlpha Data Science Internship - Task 2")
    print("=" * 60)
    
    # Step 1: Load data
    df = load_data()
    
    # Step 2: Clean data
    df = clean_data(df)
    
    # Step 3: Basic statistics
    basic_statistics(df)
    
    # Step 4: Generate visualizations
    print("\n" + "=" * 60)
    print("🎨 GENERATING VISUALIZATIONS")
    print("=" * 60)
    
    plot_unemployment_trend(df)
    state_data = plot_state_wise(df)
    covid_impact = plot_covid_impact(df)
    plot_urban_rural(df)
    plot_seasonal_trends(df)
    plot_heatmap(df)
    
    # Step 5: Print insights
    print_insights(df, state_data, covid_impact)
    
    print("\n" + "=" * 60)
    print("✅ ANALYSIS COMPLETED SUCCESSFULLY!")
    print("=" * 60)
    print("\n📁 All visualizations saved in 'visualizations/' folder")


if __name__ == "__main__":
    main()