# 🌸 Iris Flower Classification

A Machine Learning project to classify Iris flowers into three species 
(Setosa, Versicolor, Virginica) based on sepal and petal measurements.

## 📊 Project Overview
This project is part of my **Data Science Internship** task.
- **Task:** Classification
- **Dataset:** Iris Dataset (150 samples)
- **Algorithms Used:** Logistic Regression, KNN, Decision Tree, Random Forest, SVM
- **Best Accuracy Achieved:** 96.67%

## 🗂️ Project Structure
\`\`\`
Iris-Flower-Classification/
├── data/              # Dataset files
├── notebooks/         # Jupyter notebooks
├── src/               # Source code
├── models/            # Trained models
└── visualizations/    # Graphs & plots
\`\`\`

## 🚀 How to Run

1. Clone the repository
\`\`\`bash
git clone https://github.com/muhammadfarhan136/Iris-Flower-Classification.git
cd Iris-Flower-Classification
\`\`\`

2. Install dependencies
\`\`\`bash
pip install -r requirements.txt
\`\`\`

3. Run the main file
\`\`\`bash
python main.py
\`\`\`

## 📈 Results
- **Model:** Random Forest Classifier
- **Accuracy:** 96.67%
- **Precision/Recall/F1:** All above 95%

## 🛠️ Technologies Used
- Python 3.x
- Scikit-learn
- Pandas, NumPy
- Matplotlib, Seaborn
- Jupyter Notebook

## 👨‍💻 Author
**Muhammad Farhan**  
- LinkedIn: http://www.linkedin.com/in/muhammadfarhan146
- GitHub: (https://github.com/muhammadfarhan136)

## 📜 License
MIT License