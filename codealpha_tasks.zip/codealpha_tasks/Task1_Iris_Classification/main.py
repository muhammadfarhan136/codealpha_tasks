"""
Main execution file - Iris Flower Classification (Full Version)
"""
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import joblib
from sklearn.metrics import (accuracy_score, confusion_matrix, 
                              classification_report)

from src.data_loader import load_data, save_data
from src.preprocessing import preprocess_data
from src.train_model import train_model, evaluate_model, save_model
from src.predict import predict_species

def main():
    print("=" * 60)
    print("🌸 IRIS FLOWER CLASSIFICATION PROJECT 🌸")
    print("=" * 60)
    
    # Step 1: Load Data
    print("\n📥 Step 1: Loading data...")
    df, iris = load_data()
    save_data(df)
    print(f"   Dataset Shape: {df.shape}")
    print(f"   Species: {df['species_name'].unique()}")
    
    # Step 2: Preprocess
    print("\n🔧 Step 2: Preprocessing data...")
    X_train, X_test, y_train, y_test, scaler = preprocess_data(df)
    print(f"   Training samples: {len(X_train)}")
    print(f"   Testing samples: {len(X_test)}")
    
    # Step 3: Train
    print("\n🎯 Step 3: Training Random Forest model...")
    model = train_model(X_train, y_train)
    print("   ✅ Model trained successfully!")
    
    # Step 4: Evaluate
    print("\n📊 Step 4: Evaluating model...")
    accuracy, y_pred = evaluate_model(model, X_test, y_test)
    print(f"   🎯 Accuracy: {accuracy*100:.2f}%")
    
    # Classification Report
    target_names = ['setosa', 'versicolor', 'virginica']
    print("\n📋 Classification Report:")
    print(classification_report(y_test, y_pred, target_names=target_names))
    
    # Confusion Matrix
    print("📉 Generating Confusion Matrix...")
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Greens',
                xticklabels=target_names, yticklabels=target_names)
    plt.title('Confusion Matrix - Iris Classification', fontsize=14)
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.tight_layout()
    plt.savefig('visualizations/confusion_matrix.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/confusion_matrix.png")
    plt.show()
    
    # Feature Importance
    print("\n📊 Generating Feature Importance Plot...")
    importances = model.feature_importances_
    features = ['sepal length', 'sepal width', 'petal length', 'petal width']
    
    plt.figure(figsize=(8, 5))
    sns.barplot(x=importances, y=features, palette='viridis')
    plt.title('Feature Importance', fontsize=14)
    plt.xlabel('Importance Score')
    plt.tight_layout()
    plt.savefig('visualizations/feature_importance.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/feature_importance.png")
    plt.show()
    
    # Pairplot
    print("\n🎨 Generating Pairplot...")
    sns.pairplot(df.drop('species', axis=1), hue='species_name', palette='husl')
    plt.savefig('visualizations/pairplot.png', dpi=100, bbox_inches='tight')
    print("   ✅ Saved: visualizations/pairplot.png")
    plt.show()
    
    # Step 5: Save Model
    print("\n💾 Step 5: Saving model...")
    save_model(model)
    joblib.dump(scaler, 'models/scaler.pkl')
    
    # Step 6: Test Predictions
    print("\n🔮 Step 6: Testing predictions on sample flowers...")
    test_samples = [
        [5.1, 3.5, 1.4, 0.2],   # Should be Setosa
        [6.2, 2.9, 4.3, 1.3],   # Should be Versicolor
        [7.3, 2.9, 6.3, 1.8]    # Should be Virginica
    ]
    
    for sample in test_samples:
        result = predict_species(model, scaler, sample)
        print(f"   🌸 Flower {sample} → {result.upper()}")
    
    print("\n" + "=" * 60)
    print("✅ PROJECT COMPLETED SUCCESSFULLY!")
    print("=" * 60)

if __name__ == "__main__":
    main()