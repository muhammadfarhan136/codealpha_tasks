"""
Data loading module
"""
import pandas as pd
from sklearn.datasets import load_iris

def load_data():
    """Load iris dataset and return as DataFrame"""
    iris = load_iris()
    df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
    df['species'] = iris.target
    df['species_name'] = df['species'].map({
        0: 'setosa', 1: 'versicolor', 2: 'virginica'
    })
    return df, iris

def save_data(df, path='data/raw/iris.csv'):
    """Save dataset to CSV"""
    df.to_csv(path, index=False)
    print(f"✅ Data saved to {path}")