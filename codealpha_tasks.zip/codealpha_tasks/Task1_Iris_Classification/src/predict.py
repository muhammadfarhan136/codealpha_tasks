"""
Prediction module
"""
import joblib
import numpy as np
import pandas as pd

def load_model(path='models/iris_model.pkl'):
    """Load trained model"""
    return joblib.load(path)

def predict_species(model, scaler, measurements):
    """Predict species for new flower"""
    species_names = ['setosa', 'versicolor', 'virginica']
    
    # DataFrame banao with proper feature names
    feature_names = ['sepal length (cm)', 'sepal width (cm)', 
                     'petal length (cm)', 'petal width (cm)']
    sample_df = pd.DataFrame([measurements], columns=feature_names)
    
    sample_scaled = scaler.transform(sample_df)
    prediction = model.predict(sample_scaled)[0]
    return species_names[prediction]